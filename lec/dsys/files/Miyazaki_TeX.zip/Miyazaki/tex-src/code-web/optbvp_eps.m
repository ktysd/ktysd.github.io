﻿source "optbvp.m"
print -solid -deps -F:24 optbvp.eps
