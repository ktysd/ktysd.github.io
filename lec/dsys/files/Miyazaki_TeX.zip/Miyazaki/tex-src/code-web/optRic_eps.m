﻿source "optRic.m"
print -solid -deps -F:18 optRic.eps
