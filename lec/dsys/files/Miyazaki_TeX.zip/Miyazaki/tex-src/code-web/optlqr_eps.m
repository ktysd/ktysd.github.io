﻿source "optlqr.m"
xlabel("Time",'fontsize',32);drawnow;
print -solid -deps -F:32 optlqr.eps;
