﻿global m l c g;
m=1; l=1; c=1; g=9.8;
function dx=eqn(x,t)
 global m l c g;
 dx(1) = x(2);
 dx(2) = -c/(m*l*l)*x(2)-g/l*sin(x(1));
endfunction
x0=[pi/5;0];
n=100;
tt=linspace(0,10,n);
xx=lsode("eqn", x0, tt);
subplot(2,2,1); plot(tt,xx(:,1));
xlabel("t"); ylabel("x1(t)");
subplot(2,2,2); plot(tt,xx(:,2));
xlabel("t"); ylabel("x2(t)");
subplot(2,2,3); plot(xx(:,1),xx(:,2));
xlabel("x1(t)"); ylabel("x2(t)");
