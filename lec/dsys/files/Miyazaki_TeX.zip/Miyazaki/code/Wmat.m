function W = Wmat( aa )
  n = length(aa);  #�ŗL�������̎���
  W=zeros(n,n);
  for i=1:n
    for j=1:n
      if ( i+j < n+1 )
        W(i,j) = aa(i+j);
      elseif ( i+j == n+1 )
        W(i,j) = 1;
      endif
    endfor
  endfor
endfunction
