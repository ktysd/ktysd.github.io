A=[0,1; -2,-3]
[uu,lam]=eig(A);
lam1=diag(lam)(1) #diagonal component (1,1)
u1=uu(:,1)
lam2=diag(lam)(2) #diagonal component (2,2)
u2=uu(:,2)
T=[u1,u2] #same as T=uu
B=inv(T)*A*T

# (Execution Result)
# octave:> source "diagmat.m"
# A =
#    0   1
#   -2  -3
# lam1 = -1
# u1 =
#    0.70711
#   -0.70711
# lam2 = -2
# u2 =
#   -0.44721
#    0.89443
# T =
#    0.70711  -0.44721
#   -0.70711   0.89443
# B =
#   -1.00000  -0.00000
#    0.00000  -2.00000
