global om;
function dx = model(x, t)
 global om;
 m=1.0; c=0.2; k=1.0;
 dx(1)=x(2);
 dx(2)=-(c/m)*x(2)-(k/m)*x(1)+cos(om*t);
endfunction
freq = linspace(0.2,1.6,29);
__gnuplot_set__ yrange[-5:5];
__gnuplot_set__ xlabel "Time t";
__gnuplot_set__ ylabel "Amplitude x"
x0 = [0; 0.1];
t = linspace(0, 100, 300);
for i = 1:29
 om = freq(i);
 f = cos(om*t);
 x = lsode("model", x0, t);
 title(sprintf("(om = %.3f)",om));
 plot(t,f,";f(t);",t,x(:,1),";x(t);")
 sleep(0.1);
 xmax(i) = max(x(250:300, 1));
endfor
sleep(2);
__gnuplot_set__ yrange[0:5];
__gnuplot_set__ xlabel "Frequency om"
title("Response Curve");
plot(freq, xmax);
