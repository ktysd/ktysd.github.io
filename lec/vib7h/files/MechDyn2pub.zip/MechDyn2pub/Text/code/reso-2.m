global om;
function dx = model(x, t)
  global om;
  m=1.0; c=0.2; k=1.0;
  dx(1) = x(2);
  dx(2) = -(c/m)*x(2) - (k/m)*x(1) + cos(om*t);
endfunction
om=1.2;
x0 = [0; 0.1];
t = linspace(0, 100, 300);
x = lsode("model", x0, t);
plot(t,x(:,1),";x(t);")
