#plot setting
gset size square; gset ticslevel 0; gset parametric;
gset xrange[-.6:.6]; gset yrange[-.6:.6]; gset zrange[-.6:.6];
gset view 85., 60., 1.5, 1.;
# Making a wire cone
for zi=0:5
   for ti=0:20
      z = 1./5. * zi;   # 0 <= z <= 1
      if ( z > 0.5 ) 
         r=0.1+sqrt(z-0.5);
      else
         r=0.1;
      endif
      cone(1, 1+zi*21+ti) = cos(2.0*pi/20.0*ti) * r * .5;
      cone(2, 1+zi*21+ti) = sin(2.0*pi/20.0*ti) * r * .5;
      cone(3, 1+zi*21+ti) = -0.2 * (z-0.8); # rough
   endfor
endfor
#rotational matrix
function y=rotmat(a,h)
   y = [a(1)^2+(1.0-a(1)^2)*cos(h), \
           a(1)*a(2)*(1.0-cos(h))-a(3)*sin(h), \
              a(1)*a(3)*(1.0-cos(h))+a(2)*sin(h);
        a(1)*a(2)*(1.0-cos(h))+a(3)*sin(h), \
           a(2)^2+(1.0-a(2)^2)*cos(h), \
              a(2)*a(3)*(1.0-cos(h))-a(1)*sin(h);
        a(1)*a(3)*(1.0-cos(h))-a(2)*sin(h), \
           a(2)*a(3)*(1.0-cos(h))+a(1)*sin(h), \
              a(3)^2+(1.0-a(3)^2)*cos(h)];
endfunction
# 3-1-3 Euler angles
function y = E313(ph, th, ps)
   y = rotmat([0. 0. 1.],ph)*rotmat([1. 0. 0.],th)*rotmat([0. 0. 1.],ps);
endfunction

global J1 J2 J3;
function dx = top(x,t)
   global J1 J2 J3;
   ph = x(1); dph = x(2);
   th = x(3); dth = x(4);
   ps = x(5); dps = x(6);
   A = [J1*sin(th)^2+J3*cos(th)^2, 0, J3*cos(th); 0, J1, 0; J3*cos(th), 0, J3];
   b = [2*(J3-J1)*dph*dth*cos(th) + J3*dps*dth; (J1-J3)*dph^2*cos(th) - J3*dph*dps; J3*dph*dth];
   h = A\b; #(Aの逆行列)*bと同じ．inv(A)*bと書くより速い
   dx(1) = x(2); dx(2) = h(1);
   dx(3) = x(4); dx(4) = h(2);
   dx(5) = x(6); dx(6) = h(3);
endfunction

J1=1.0; J2=1.0; J3=1.5;
x=[ 0 , 5   ,   0.5 , 1   ,   0 , 10]';
#lsode_options("absolute tolerance", 1.0e-5);
lsode_options("integration method", "adams");
for i=0:250
    obj= E313(x(1),x(3),x(5))*cone;
   gsplot obj';
   x = (lsode( "top", x, [0, 0.1] ))(2,:);
   sleep(0.1);
#   usleep(100);
   if ( i==0 ) sleep(2); endif
endfor
