prefix="kiri07sl"
progname=`basename $0`
if [ $# = 1 ]; then
  chapno=`basename $1 .tex`
  if [ $chapno = "all" ]; then
     echo "" > SELECT.tex
     platex slide.tex
     platex slide.tex
     dvipdfmx -p 105mm,297mm slide.dvi
     mv slide.pdf ${prefix}_all.pdf
  elif [ -f $chapno.tex ]; then
     echo "" > SELECT.tex
     platex slide.tex
     platex slide.tex
     comline="echo \"\\includeonly{"$chapno"}\" > SELECT.tex"
     echo $comline
     eval $comline
     platex slide.tex
     platex slide.tex
     dvipdfmx -p 105mm,297mm slide.dvi
     echo "mv slide.pdf ../PDF/${prefix}_$chapno.pdf"
     mv slide.pdf ../PDF/${prefix}_$chapno.pdf
  else
     echo "quit: $chapno.tex does not exists."
  fi
else
  echo "Usage: $progname {chapter_number,all}"
fi
