prefix="kiriki"
progname=`basename $0`
if [ $# = 1 ]; then
  chapno=`basename $1 .tex`
  if [ $chapno = "all" ]; then
     echo "" > SELECT.tex
     platex main.tex
     platex main.tex
     dvipdfmx main.dvi
     mv main.pdf ../PDF/${prefix}_all.pdf
  elif [ $chapno = "color" ]; then
     echo "" > SELECT.tex
     platex main_color.tex
     platex main_color.tex
     dvipdfmx main_color.dvi
     mv main_color.pdf ../PDF/${prefix}_color.pdf
  elif [ -f $chapno.tex ]; then
     echo "" > SELECT.tex
     platex main.tex
     platex main.tex
     comline="echo \"\\includeonly{"$chapno"}\" > SELECT.tex"
     echo $comline
     eval $comline
     platex main.tex
     platex main.tex
     dvipdfmx main.dvi
     echo "mv main.pdf ../PDF/${prefix}_$chapno.pdf"
     mv main.pdf ../PDF/${prefix}_$chapno.pdf
  else
     echo "quit: $chapno.tex does not exists."
  fi
else
  echo "Usage: $progname {chapter_number,all}"
fi
