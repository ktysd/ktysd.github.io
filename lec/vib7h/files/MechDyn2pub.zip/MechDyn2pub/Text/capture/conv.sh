mv s1.-1-5i.s2.-1+5i.PNG s-1-5is-1+5i.PNG
mv s1.-5.s2.-2.PNG s-5s-2.PNG
mv s1.-5i.s2_5i.PNG s-5is5i.PNG
mv s1.1-5i.s2.1+5i.PNG s1-5is1+5i.PNG
mv s1.5.s2.2.PNG s5s2.PNG
mv s1_-5.s2.2.PNG s-5s2.PNG
