m = 1.0; c = 0.5; k = 1.0;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-(c/m)*x(2)-(k/m)*x(1);
 return dx';
}
z0=[1,0]';

c=0.0;
{t,z}=OdeAuto(0.0,25.0,z0,eqn);
gplot_cmd("set output \"02-5.eps\"");
gplot_cmd("set term po eps 48");
gplot_cmd("set ytics -1,0.5,1\nset mytics 5");
gplot(t,z(1,:),{""});

gplot_cmd("set output \"02-6.eps\"");
c=0.4;
{t,z}=OdeAuto(0.0,25.0,z0,eqn);
gplot(t,z(1,:),{""});

gplot_cmd("set output \"02-7.eps\"");
c=2.0;
{t,z}=OdeAuto(0.0,25.0,z0,eqn);
gplot(t,z(1,:),{""});
