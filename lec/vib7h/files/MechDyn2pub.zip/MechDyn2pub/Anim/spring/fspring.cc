#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Rkg.h"

#define POW2(a) ((a)*(a))
class Model: public Rkg4 {

 public:
   double  m;
   double  c;
   double  k;
   double  A;
   double  om;
   double  F;
   int    omi, omn;
   double oom[2], dom;
   Model(): Rkg4(2) { /* ..(4).. means dimension 4 */
      m   = 9.0;
//      c   = 0.15;
      c   = 0.25;
      k   = 4.0;
      om  = 1.0;
      A   = 7.0;
      dt(0.02);
      nonperiodic();
      x(1) = 0.0;
      x(2) = 0.0;
      omi = 0;
      omn = 20000;
      oom[0]= 0.5;
      oom[1]= 1.0;
   }

  void ode() {
    F = A*cos(om*t());
    dx(1) = x(2);
    dx(2) = -c/m*x(2) -k/m*x(1)
           + A/m*( POW2(om)*cos(om*t()) + c*om*sin(om*t()) - k*cos(om*t()) );
  }

};


Model model;

void draw_spring( double w, double x, double r, double y1, double y2 ) {
  double h=y2-y1-2.0*r;
  double spring_p[8][2];
  spring_p[0][0]=0.0;
  spring_p[0][1]=0.0;
  spring_p[1][0]=0.5*w;
  spring_p[1][1]=h/12.0;
  for ( int i=2; i<7; i++ ) {
    spring_p[i][0]=-spring_p[i-1][0];
    spring_p[i][1]=spring_p[i-1][1]+h/6.0;
  }
  spring_p[7][0]=0.0;
  spring_p[7][1]=h;
  
  glPushMatrix();
    glTranslated( 0.0, r, 0.0 );
    glColor3d(0.0, 0.0, 0.0);
    glBegin(GL_LINE_STRIP);
      glVertex2d(x, y1-r );
      for ( int i=0; i<8; i++ ) {
         glVertex2d(x+spring_p[i][0],y1+spring_p[i][1]);
      }
      glVertex2d(x, y1+h+r );
    glEnd();
  glPopMatrix();
}

void draw_color_box( double x1, double y1, double x2, double y2,
                double r, double g, double b ) {
  glPushMatrix();
    glColor3d(r, g, b);
    glPolygonMode(GL_FRONT, GL_FILL);
    glPolygonMode(GL_BACK, GL_LINE);
    glBegin(GL_QUADS);
      glVertex2d(x1, y1 );
      glVertex2d(x1, y2 );
      glVertex2d(x2, y2 );
      glVertex2d(x2, y1 );
    glEnd();
  glPopMatrix();
}

void draw_mass( double w, double h, double x, double y ) {
   draw_color_box( -0.5*w, h+y, 0.5*w, y, 0.3, 0.3, 0.3 ); 
}

void draw_axis( double x0, double y0, double bot ) {
  glPushMatrix();
    draw_color_box( -1.0, bot, 1.0, -1.0, 0.5, 0.5, 0.5 ); 
    draw_color_box( -1.0, 1.0, 1.0, bot, 240./256., 230./256., 140./256. ); 
    draw_color_box( x0-1.0, y0+0.005, x0+1.0, y0-0.005, 1.0, 0.0, 0.0 ); 
  glPopMatrix();
}

double Fratio = 0.01, Xratio=0.005;
int dir = 1;
void display(void) {
  double height;
  if ( model.omi == 0 ) {
     dir ++;
     model.dom = (model.oom[(dir+1)%2]-model.oom[(dir)%2])
                                       /(double)(model.omn-1);
  }
  model.om = model.oom[(dir)%2] + (double)model.omi * model.dom;
  model.set_t((model.om - model.dom)/model.om*model.t()) ;
  for ( int i=0; i<(int)(model.oom[1]/model.om); i++ ) {
  height = Xratio*model.x(1);
  model.solve(3);
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  draw_axis( 0.0, 0.4, -0.85-Fratio*model.F );
  draw_spring( 0.5, 0.0, 0.2, -0.85-Fratio*model.F, 0.2+height );
  draw_mass( 0.8, 0.4, 0.0, 0.2+height );
  glutSwapBuffers();
  }
  model.omi ++;
  if ( model.omi >= model.omn ) {
     model.omi = 0;
  }
}

void idle(void) {
  glutPostRedisplay();
}

void mouse(int button, int state, int x, int y) {
  static int is_stop = 1;
  switch (button) {
  case GLUT_LEFT_BUTTON:
    if (state == GLUT_DOWN) {
      if ( is_stop ) {
        is_stop = 0;
        glutIdleFunc(idle);
      }
      else {
        is_stop = 1;
        glutIdleFunc(0);
      }
    }
    break;
  case GLUT_RIGHT_BUTTON:
    if (state == GLUT_DOWN) {
      exit(0);
    }
    break;
  default:
    break;
  }
}
  
void keyboard(unsigned char key, int x, int y) {
  switch (key) {
  case 'q':
  case 'Q':
  case '\033':  /* ESC */
    exit(0);
  default:
    break;
  }
}

void init(void) {
  glClearColor(1.0, 1.0, 1.0, 0.0);
}

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
  glutCreateWindow(argv[0]);
  glutDisplayFunc(display);
  glutMouseFunc(mouse);
  glutKeyboardFunc(keyboard);
  init();
//  glutIdleFunc(idle);
  glutIdleFunc(0);
  glutMainLoop();
  return 0;
}
