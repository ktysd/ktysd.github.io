#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Rkg.h"

class Model: public Rkg4 {

 public:
   double  m;
   double  c;
   double  k;
   double  om;
   Model(): Rkg4(2) { /* ..(4).. means dimension 4 */
      m   = 9.0;
      c   = 0.15;
      k   = 4.0;
      om  = 1.0;
      dt(0.01);
      nonperiodic();
      x(1) = 0.0;
      x(2) = 0.0;
   }

   void ode() {
      dx(1) = x(2);
      dx(2) = -c*x(2) -k*x(1);
   }

};


Model model;

void draw_spring( double w, double x, double r, double y1, double y2 ) {
  double h=y2-y1-2.0*r;
  double spring_p[8][2];
  spring_p[0][0]=0.0;
  spring_p[0][1]=0.0;
  spring_p[1][0]=0.5*w;
  spring_p[1][1]=h/12.0;
  for ( int i=2; i<7; i++ ) {
    spring_p[i][0]=-spring_p[i-1][0];
    spring_p[i][1]=spring_p[i-1][1]+h/6.0;
  }
  spring_p[7][0]=0.0;
  spring_p[7][1]=h;
  
  glPushMatrix();
    glTranslated( 0.0, r, 0.0 );
    glColor3d(0.0, 0.0, 0.0);
    glBegin(GL_LINE_STRIP);
      glVertex2d(x, y1-r );
      for ( int i=0; i<8; i++ ) {
         glVertex2d(x+spring_p[i][0],y1+spring_p[i][1]);
      }
      glVertex2d(x, y1+h+r );
    glEnd();
  glPopMatrix();
}

void draw_color_box( double x1, double y1, double x2, double y2,
                double r, double g, double b ) {
  glPushMatrix();
    glColor3d(r, g, b);
    glPolygonMode(GL_FRONT, GL_FILL);
    glPolygonMode(GL_BACK, GL_LINE);
    glBegin(GL_QUADS);
      glVertex2d(x1, y1 );
      glVertex2d(x1, y2 );
      glVertex2d(x2, y2 );
      glVertex2d(x2, y1 );
    glEnd();
  glPopMatrix();
}

void draw_mass( double w, double h, double x, double y ) {
   draw_color_box( -0.5*w, h+y, 0.5*w, y, 0.3, 0.3, 0.3 ); 
}

void draw_axis( double x0, double y0, double bot ) {
  glPushMatrix();
    draw_color_box( -1.0, bot, 1.0, -1.0, 0.5, 0.5, 0.5 ); 
    draw_color_box( -1.0, 1.0, 1.0, bot, 240./256., 230./256., 140./256. ); 
    draw_color_box( x0-1.0, y0+0.005, x0+1.0, y0-0.005, 1.0, 0.0, 0.0 ); 
  glPopMatrix();
}

long nfrm = 0, nwait=150;
void display(void) {
  double height;
  if ( nfrm > 2500 ) nfrm=0;
  if ( nfrm < nwait ) {
     model.x(1) = height = 0.35*(double)nfrm/(double)nwait;
  }
  else if ( nfrm < nwait+80 ) {
     height = 0.35;
  }
  else {
     height = model.x(1);
     model.solve(3);
  }
  nfrm ++;
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  draw_axis( 0.0, 0.4, -0.85 );
  draw_spring( 0.5, 0.0, 0.2, -0.85, 0.2+height );
  draw_mass( 0.8, 0.4, 0.0, 0.2+height );
  glutSwapBuffers();
}

void idle(void) {
  glutPostRedisplay();
}

void mouse(int button, int state, int x, int y) {
  static int is_stop = 1;
  switch (button) {
  case GLUT_LEFT_BUTTON:
    if (state == GLUT_DOWN) {
      if ( is_stop ) {
        is_stop = 0;
        glutIdleFunc(idle);
      }
      else {
        is_stop = 1;
        glutIdleFunc(0);
      }
    }
    break;
  case GLUT_RIGHT_BUTTON:
    if (state == GLUT_DOWN) {
      exit(0);
    }
    break;
  default:
    break;
  }
}
  
void keyboard(unsigned char key, int x, int y) {
  switch (key) {
  case 'q':
  case 'Q':
  case '\033':  /* ESC */
    exit(0);
  default:
    break;
  }
}

void init(void) {
  glClearColor(1.0, 1.0, 1.0, 0.0);
}

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
  glutCreateWindow(argv[0]);
  glutDisplayFunc(display);
  glutMouseFunc(mouse);
  glutKeyboardFunc(keyboard);
  init();
//  glutIdleFunc(idle);
  glutIdleFunc(0);
  glutMainLoop();
  return 0;
}
