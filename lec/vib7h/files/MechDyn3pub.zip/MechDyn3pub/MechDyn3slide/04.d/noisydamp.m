t=linspace(0,1,2000);
x=2.0+0.1*randn(1,length(t))+0.07*cos(5*t)+0.05*t-0.04;
printf("%e %e\n",[t;x]);

