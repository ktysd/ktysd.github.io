/*
 * R.K.G numerical integration
 *
 * Last update: 12 Jun 2003 by yoshidak@cc.utsunomiya-u.ac.jp
 */
#ifndef __RKG4_H_
#define __RKG4_H_

#include <iostream>
//#include <strstream.h>
using namespace std; 

class Rkg4 {
  protected:
   unsigned long _dim;  // ����
   double       _t0;   // ��������
   double       _t;    // ����
   double       _dt;   // ���Ԃ�����
   double*      _x;    // ��ԕϐ�
   double*      _dx;   // ��ԕϐ��̔���
   double*      _kk;   // RKG �p
   double*      _qq;   // RKG �p

   unsigned int  _isperiodic;
   long          _inc;
   long          _step;
   double        _freq;

   virtual void ode(){}
   void rkg4( void ) {
      long i;
      long imin = 0;
      long imax = _dim;

      ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += 0.5 * _kk[i]; 
         _qq[i] = _kk[i];
      }

      _t += 0.5*_dt; ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += ( 1.0 - 0.5 * M_SQRT2 )*( _kk[i] - _qq[i] );
         _qq[i] = ( -2.0 + 3.0 * M_SQRT1_2 )*_qq[i] + ( 2.0 - M_SQRT2 )*_kk[i];
      }

      ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += ( 1.0 + M_SQRT1_2 )*( _kk[i] - _qq[i] );
         _qq[i] = -( 2.0 + 3.0 * M_SQRT1_2 )*_qq[i] + ( 2.0 + M_SQRT2 )*_kk[i];
      }

      _t += 0.5*_dt; ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += _kk[i]/6.0 - _qq[i]/3.0;
      }
   }

  public:
   Rkg4( unsigned long dimen ) {
      _dim  = dimen;
      _t0   = 0.0;
      _dt   = 0.01;
      _t    = _t0;
      _x    = new double[_dim];
      _dx   = new double[_dim];
      _kk   = new double[_dim];
      _qq   = new double[_dim];

      _inc        = 0;
      _step       = 1;
      _freq       = 0.0;
      _isperiodic = 0;

   }
   virtual ~Rkg4() { 
      delete _x;
      delete _dx;
      delete _kk;
      delete _qq;
   }

   unsigned long indx( unsigned long i ) {
#ifdef DEBUG
      if ( i < 1 || _dim < i ) {
         cerr << "***Rkg4: index is out of range" << endl;
         exit( -1 );
      }
#endif
      return ( i-1 );
   }

   double dim( void ) {
      return _dim;
   }
   double t( void ) {
      return _t;
   }
   void set_t( double tt ) {
      _t = tt;
   }
   double t0( void ) {
      return _t0;
   }
   double dt( void ) {
      return _dt;
   }
   double &x( long i ) {
      return _x[indx(i)];
   }
   double x_mod_2pi( long i ) {
      double pi2 = 2.0*M_PI;
      double xx = fmod( _x[indx(i)], pi2 );
      if ( xx > M_PI ) xx -= pi2;
      else if ( xx < -M_PI ) xx += pi2;
      return xx;
   }
   double &dx( long i ) {
      return _dx[indx(i)];
   }
   unsigned long step( void ) {
      return _step;
   }
   double &freq( void ) {
      return _freq;
   }

   Rkg4& dt( double Dt ) {
      _dt = Dt;
      return *this;
   }
   Rkg4& t0( double T0 ) {
      _t = _t0 = T0;
      return *this;
   }
   Rkg4& step( unsigned long Step ) {
      _step = Step;
      return *this;
   }
   Rkg4& freq( double Freq ) {
      if ( _step <= 0 ) {
         cerr << "***Rkg4: invalid order of function call." << endl;
         cerr << "         call step(?), then call freq(?)" << endl;
         exit(-1);
      }
      _freq = Freq;
      _dt = 2.0*M_PI/_freq/(double)_step;
      return *this;
   }
   double period( ) {
      return 2.0*M_PI/_freq;
   }
   Rkg4& periodic( void ) {
      _isperiodic = 1;
      return *this;
   }
   Rkg4& nonperiodic( void ) {
      _isperiodic = 0;
      return *this;
   }

   void solve( int rept=1 ) {
      for ( int i=0; i<rept; i++ ) {
         rkg4();

         _inc = (++_inc)%_step;
         if ( _inc == 0 && _isperiodic ) {
            _t = _t0;
         }
      }
   }

// katu
   void solve_without_update_time( ) {
      rkg4();
      _t -= _dt;
   }
   void update_time( ) {
      _inc = (++_inc)%_step;
      _t += _dt;
      if ( _inc == 0 && _isperiodic ) {
         _t = _t0;
      }
   }

   void poincare( void ) {
      if ( _step <= 0 ) {
         cerr << "***Rkg4: step == 0 for poincare" << endl;
         cerr << "         call step(nonzero) before" << endl;
         exit(-1);
      }
      solve(_step);
   }

};

#endif /* __RKG4_H_ */
