#!/bin/sh
exec ./spring
