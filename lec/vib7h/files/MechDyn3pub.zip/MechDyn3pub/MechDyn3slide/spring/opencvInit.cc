const double FPS(15.0);
#if 0
const int window_width ( 600 );
const int window_height( 600 );
#endif


IplImage* video_buf;
IplImage* video;
CvVideoWriter* videowriter;

void opencvInit()
{
  video_buf = cvCreateImage(cvSize(window_width,window_height), IPL_DEPTH_8U, 3);
  video = cvCreateImage(cvSize(window_width,window_height), IPL_DEPTH_8U, 3);
  videowriter 
    = cvCreateVideoWriter(
			  "gl_video.avi",
			  //"gl_video.mov",
			  //CV_FOURCC('P','I','M','1') ,  // MPEG-1
			  //CV_FOURCC('D','I','V','X') ,  // Divx 
			  //CV_FOURCC('M','P','G','4') ,  // MPEG-4 
			  //CV_FOURCC('M','P','4','2') ,  // MPEG-4.2
			  //CV_FOURCC('D','I','V','3') ,  // MPEG-4.3
			  CV_FOURCC('X','V','I','D') ,  // Xvid
			  //CV_FOURCC('D','X','5','0') ,  // Dvix ver5
			  //CV_FOURCC('U','2','6','3') ,  // H263
			  //CV_FOURCC('I','2','6','3') ,  // H263I
			  //CV_FOURCC('H','2','6','4') ,  // H264
			  //CV_FOURCC('F','L','V','1') ,  // FLV
			  //CV_FOURCC('M','J','P','G') ,  // Motion JPEG
			  //CV_FOURCC('2','v','u','y') ,  // 
			  FPS ,
			  cvSize(video->width,
				 video->height),
			  1 );
}

