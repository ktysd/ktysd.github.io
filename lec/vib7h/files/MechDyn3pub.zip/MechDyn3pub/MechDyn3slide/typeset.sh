#platex book; platex book
#mendex book
#platex main
dvipdfmx -p 257mm,182mm main.dvi

