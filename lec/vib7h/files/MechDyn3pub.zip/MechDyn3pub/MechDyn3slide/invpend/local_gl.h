/*graphics*/
#include <GL/glut.h>
#define D_TIMER 20

int first = 1;
int is_stop = 1;

/* blue system */
int    mouse_x_prev= 0, //�ޥ����θ��߰��֤ȼ������֡�old��
       blue_force_cut = 1;
double difblue = 0.0, //����¤˲ä��볰��
        B = 0.00175; //�������ɸ�ͤ˳ݤ��뷸����good B=0.00175��

/* main system */
static void gl_display(void);
static void gl_timer( int dummy );
static void gl_motion(int x, int y);
static void gl_pass_motion(int x, int y);
static void gl_keyboard(unsigned char key, int x, int y);
static void gl_mouse(int button, int state, int x, int y);

static void gl_display(void)
{
  double x1, x2, th1, th2;
  x1  = model->x(1);
  th1 = model->x(3);
  x2  = model->x(5);
  th2 = model->x(7);

  double scale = 1.0;    // ��Ψ
  double r = 0.3;   // ��������Ĺ��
  double x[4], y[4];
  x[0] = scale*x1;  y[0] = 0.0;    // ���1�κ�ɸ
  x[1] = scale*(x1+r*sin(th1));  y[1] = scale*r*cos(th1); // ����1�κ�ɸ
  x[2] = scale*(x2+r*sin(th2));  y[2] = scale*r*cos(th2); // ����2�κ�ɸ
  x[3] = scale*x2;  y[3] = 0.0;    // ���2�κ�ɸ

/* graphics system */
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
// glTranslated(-0.5*(x[0]+x[3]), -0.5*r, 0.0);
// glTranslated(-0.5*l, -0.5*r, 0.0);
  glScaled(1.0, 2.0, 1.0);
  
  gluLookAt(0.5*(x[0]+x[3]), 0.0, 0.1, 0.5*(x[0]+x[3])
            , 0.0, 0.0, 0.0, 1.0, 0.0);
  
  glLineWidth(1.0); 
  glColor3d(0.5, 0.5, 0.5); //��ɸ���ʳ���
  glBegin(GL_LINES);
    glVertex2d( 0.5*(x[0]+x[3])-1.0, y[0] );
    glVertex2d( 0.5*(x[0]+x[3])+1.0, y[0] );
  glEnd();

  glLineWidth(4.0);
  glColor3d(1.0, 0.5, 0.5); //�����֡���¡���������
  glBegin(GL_LINES);
    glVertex2d( x[0], y[0] );
    glVertex2d( x[1], y[1] );
  glEnd();
  glBegin(GL_QUADS);
  glVertex2d(x[0]-0.05, -0.025);
  glVertex2d(x[0]-0.05, +0.025);
  glVertex2d(x[0]+0.05, +0.025);
  glVertex2d(x[0]+0.05, -0.025);
  glEnd();

  glColor3d(0.5, 0.5, 1.0); //�����ġ���¡��������
  glBegin(GL_LINES);
    glVertex2d( x[2], y[2] );
    glVertex2d( x[3], y[3] );
  glEnd();
  glBegin(GL_QUADS);
  glVertex2d(x[3]-0.05, -0.025);
  glVertex2d(x[3]-0.05, +0.025);
  glVertex2d(x[3]+0.05, +0.025);
  glVertex2d(x[3]+0.05, -0.025);
  glEnd();

  glColor3d(0.5, 1.0, 0.5); //�����С�
  glBegin(GL_LINES);
    glVertex2d( x[1], y[1] );
    glVertex2d( x[2], y[2] );
  glEnd();
#if 0
  glColor3d(0.0, 0.0, 0.0);
  glBegin(GL_LINES);
     for ( int j=1; j<4; j++ ) {
        glVertex2d( x[j-1], y[j-1] );
        glVertex2d( x[j], y[j] );
     }
  glEnd();
#endif
  
  //fflush( stdout );

  glutSwapBuffers();

}

int itime = 0;
static void gl_timer( int dummy ) {
   if ( ! is_stop) {
     model->solve_with_check(5);
     model->solve_with_check(5);
     //     if ( model->is_converged ) {
     //        printf( "%d %d\n", model->equil[0], model->equil[1] );
     //     }
   }
   glutPostRedisplay () ;
   glutTimerFunc ( D_TIMER, gl_timer, 0 );
}

int is_first_pos = 1;
int first_pos = 0;

static void gl_motion(int x, int y) {
     if ( is_first_pos == 1 ) {
	   first_pos = x;
	   is_first_pos = 0;
           blue_force_cut =1;
     }
     blue_force_cut = 1;
     difblue = x - first_pos;
}

static void gl_pass_motion(int x, int y) {
     is_first_pos = 1;
     blue_force_cut = 0;
}

static void gl_keyboard(unsigned char key, int x, int y) {
  switch (key) {
  case 's':
    if ( is_stop ) {
       is_stop = 0;
    } else {
       is_stop = 1;
    }
    glutTimerFunc ( D_TIMER, gl_timer, 0 );
    break;
  case 'q':
    exit(0);
  default:
    break;
  }
}

void gl_mouse(int button, int state, int x, int y)
{
  switch (button) {
  case GLUT_LEFT_BUTTON:
    if ( state == GLUT_UP ) {
      if ( is_stop ) {
         is_stop = 0;
      } else {
         is_stop = 1;
      }
      glutTimerFunc ( D_TIMER, gl_timer, 0 );
    }
    break;
  case GLUT_MIDDLE_BUTTON:
    printf("middle");
    break;
  case GLUT_RIGHT_BUTTON:
//    printf("Normal Termination\n");
    exit(0);
    break;
  default:
    break;
  }
}

