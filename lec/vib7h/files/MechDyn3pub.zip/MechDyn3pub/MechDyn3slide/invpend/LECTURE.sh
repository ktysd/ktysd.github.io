#!/bin/bash
proc () { xmessage "Over-damping"; ./invpend 1 0; ./invpend 1 1; xmessage "Under-damping"; ./invpend 2 0; ./invpend 2 1; }
proc &
octave -q freqres.m

