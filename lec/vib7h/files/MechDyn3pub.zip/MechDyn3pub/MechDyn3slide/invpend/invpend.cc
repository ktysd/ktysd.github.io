/* 2007-11-21 yoshidak */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*-------------------------------------*/
#include "Rkg++.h"

#define POW2(a) ((a)*(a))
class Model: public Rkg4 {
 public:
   double om, A, cosomt;
   double g, m1, m2, l;
   double Kx, Kth, Lx, Lth;
   int is_converged, equil[2];
   Model(double time_step = 0.01): Rkg4(4) {

      noperiodic(time_step);
      om = A = 1.0;
      g = 9.8;
      m1=2.0/3.0; /* mass of cart */
      m2=1.0-m1;  /* mass of pendulumn */
      l=1.0;      /* length of pendulumn */
      x(1) = 0.0;
      x(2) = 0.0;
      x(3) = 0.5;
      x(4) = 0.0;
  }

  void ode() {

    cosomt = cos(om*t());
    double xx = x(1), dxx = x(2), th = x(3), dth = x(4);
    double A11 = m1+m2,   A12 = m2*l*cos(th);
    double A21 = cos(th), A22 = l;
    double ft = Kx*xx + Lx*dxx + Kth*th + Lth*dth;
    double b1  = m2*l*POW2(dth)*sin(th) + ft + A*(1.0)*cosomt;
    double b2  = g*sin(th);
    double detA = A11*A22 - A21*A12;
    double B11 = A22/detA, B12 = -A12/detA;
    double B21 = -A21/detA, B22 = A11/detA;
    double h1 = B11*b1 +  B12*b2;
    double h2 = B21*b1 +  B22*b2;

    dx(1) = x(2);
    dx(2) = h1;
    dx(3) = x(4);
    dx(4) = h2;
   }   
};
Model *model;
/*-------------------------------------*/
#include <GL/glut.h>
#define D_TIMER 120

int first = 1;
int is_stop = 1;

/* blue system */
int    mouse_x_prev= 0, //マウスの現在位置と手前位置（old）
       blue_force_cut = 1;
double difblue = 0.0, //青台座に加える外力
        B = 0.00175; //青台座目標値に掛かる係数（good B=0.00175）

/* main system */
static void gl_display(void);
static void gl_timer( int dummy );
static void gl_motion(int x, int y);
static void gl_pass_motion(int x, int y);
static void gl_keyboard(unsigned char key, int x, int y);
static void gl_mouse(int button, int state, int x, int y);

static void gl_display(void)
{
  double x1, th1;
  x1  = model->x(1);
  th1 = model->x(3);

  double scale = 1.0;    // 倍率
  double r = 0.3;   // 振子棒の長さ
  double x[2], y[2], G[2];
  x[0] = scale*x1;  y[0] = 0.0;    // 台座1の座標
  x[1] = scale*(x1+r*sin(th1));  y[1] = scale*r*cos(th1); // 質点1の座標
  G[0] = (model->m1*x[0]+model->m2*x[1])/(model->m1+model->m2);
  G[1] = (model->m1*y[0]+model->m2*y[1])/(model->m1+model->m2);

/* graphics system */
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();
  glTranslated(0, -0.2, 0);
  glScaled(3.0, 3.0, 3.0);
//  glScaled(1.0, 2.0, 1.0);
  
  //gluLookAt(G[0], 0.0, 0.1, G[0], 0.0, 0.0, 0.0, 1.0, 0.0);
  gluLookAt(G[0], 0.0, 0.1, G[0], 0.0, 0.0, 0.0, 1.0, 0.0);
  
  glLineWidth(1.0); 
  glColor3d(0.5, 0.5, 0.5); //座標軸（灰）
  glBegin(GL_LINES);
    glVertex2d( G[0]-1.0, y[0] );
    glVertex2d( G[0]+1.0, y[0] );
  glEnd();

  glLineWidth(20.0);
//  glColor3d(1.0, 0.5, 0.5); //左（赤）台座（制御部）
  glColor3d(0.5, 0.5, 0.8);
  glBegin(GL_LINES);
    glVertex2d( x[0], y[0] );
    glVertex2d( x[1], y[1] );
  glEnd();
  glBegin(GL_QUADS);
  glVertex2d(x[0]-0.05, -0.025);
  glVertex2d(x[0]-0.05, +0.025);
  glVertex2d(x[0]+0.05, +0.025);
  glVertex2d(x[0]+0.05, -0.025);
  glEnd();

  glutSwapBuffers();

}

int itime = 0, nstep = 80;
int iom = 0, nom = 10;
double rom[] = { 1.5, 2.5 };
double dom = (rom[1]-rom[0])/(double)nom;
static void gl_timer( int dummy ) {
   if ( ! is_stop) {
      if ( itime == 0 ) {
         model->om = rom[0] + dom*(double)iom;
         model->scale_t( 1.0 - dom/model->om );
         iom ++;
         printf ( "%f\n", model->om );
      }
      if ( fabs(model->x(3)) > 0.3*M_PI ) {
         model->Kx = 0; model->Lx = -0.5;
         model->Kth = 0; model->Lth = -0.5;
         model->A = 0;
         model->solve(16);
      }
      else {
         model->solve(16);
      }
//      printf ( "%f %f\n", model->cosomt, model->om );
      itime = (itime + 1)%nstep;
   }
   glutPostRedisplay () ;
   glutTimerFunc ( D_TIMER, gl_timer, 0 );
}

int is_first_pos = 1;
int first_pos = 0;

static void gl_motion(int x, int y) {
     if ( is_first_pos == 1 ) {
	   first_pos = x;
	   is_first_pos = 0;
           blue_force_cut =1;
     }
     blue_force_cut = 1;
     difblue = x - first_pos;
}

static void gl_pass_motion(int x, int y) {
     is_first_pos = 1;
     blue_force_cut = 0;
}

static void gl_keyboard(unsigned char key, int x, int y) {
  switch (key) {
  case 's':
    if ( is_stop ) {
       is_stop = 0;
    } else {
       is_stop = 1;
    }
    glutTimerFunc ( D_TIMER, gl_timer, 0 );
    break;
  case 'q':
    exit(0);
  default:
    break;
  }
}

void gl_mouse(int button, int state, int x, int y)
{
  switch (button) {
  case GLUT_LEFT_BUTTON:
    if ( state == GLUT_UP ) {
      if ( is_stop ) {
         is_stop = 0;
      } else {
         is_stop = 1;
      }
      glutTimerFunc ( D_TIMER, gl_timer, 0 );
    }
    break;
  case GLUT_MIDDLE_BUTTON:
    printf("middle");
    break;
  case GLUT_RIGHT_BUTTON:
//    printf("Normal Termination\n");
    exit(0);
    break;
  default:
    break;
  }
}

/*-------------------------------------*/

int main(int argc, char *argv[]) {

   model = new Model;
   model->Kx  = 0.0; //0.7;
   model->Lx  = 0.0; //1.3;
   model->Kth = 20.0;
   model->Lth = 4.0;

   int gain_mode = 0;
   if ( argc == 1 +2) {
      gain_mode = atoi(argv[1]);
      model->A = atof(argv[2]);
   }
   else {
      fprintf( stderr, "usage: %s {1,2} {0,1}\n", argv[0] ); return 0;
   }

   switch ( gain_mode ) {
    case 1: // over
      model->Kth = 15.0;
      model->Lth = 3.0;
      printf( "# over damping\n" );
      break;
    case 2: // under
      model->Kth = 15.0;
      model->Lth = 0.5;
      printf( "# under damping\n" );
      break;
    default:
      fprintf( stderr, "usage: %s {1,2}\n", argv[0] ); return 0;
      break;
   }

   if ( model->A ) {
      model->x(3) = 0.0;
   }

#if 0
   for ( int i=0; i<20; i++ ) {
      model->solve();
      printf( "%f %f %f %f\n", model->x(1), model->x(2), 
                              model->x(3), model->x(4) );
   }
#else
//   glutInitWindowSize(650, 650);
//   glutInitWindowSize(700, 350);
   glutInitWindowSize(480, 480);
   glutInitWindowPosition(100, 0);
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
   glutCreateWindow(argv[0]);
   glutDisplayFunc(gl_display);
   glutKeyboardFunc(gl_keyboard);
   glutMotionFunc(gl_motion);
   glutMouseFunc(gl_mouse);
   glutPassiveMotionFunc(gl_pass_motion);
   glutTimerFunc ( D_TIMER, gl_timer, 0 );
   glClearColor(1.0, 1.0, 1.0, 0.0);
   glutMainLoop();
#endif

   return 0;
}

