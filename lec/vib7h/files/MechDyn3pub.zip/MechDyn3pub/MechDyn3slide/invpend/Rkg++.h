/*
 * R.K.G numerical integration
 *
 * Last update: 2006/09/25 by yoshidak@cc.utsunomiya-u.ac.jp
 */
#ifndef __RKG4pp_H_
#define __RKG4pp_H_

#include <iostream>
using namespace std;

class Rkg4 {
  protected:
   unsigned long _dim;  // 次元
   double       _t0;   // 初期時刻
   double       _t;    // 時刻
   double       _dt;   // 時間きざみ
   double*      _x;    // 状態変数
   double*      _dx;   // 状態変数の微分
   double*      _kk;   // RKG 用
   double*      _qq;   // RKG 用

   unsigned int  _isperiodic;
   long          _inc;
   long          _step;
   double        _freq;

   virtual void ode(){}
   void rkg4( void ) {
      long i;
      long imin = 0;
      long imax = _dim;

      ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += 0.5 * _kk[i]; 
         _qq[i] = _kk[i];
      }

      _t += 0.5*_dt; ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += ( 1.0 - 0.5 * M_SQRT2 )*( _kk[i] - _qq[i] );
         _qq[i] = ( -2.0 + 3.0 * M_SQRT1_2 )*_qq[i] + ( 2.0 - M_SQRT2 )*_kk[i];
      }

      ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += ( 1.0 + M_SQRT1_2 )*( _kk[i] - _qq[i] );
         _qq[i] = -( 2.0 + 3.0 * M_SQRT1_2 )*_qq[i] + ( 2.0 + M_SQRT2 )*_kk[i];
      }

      _t += 0.5*_dt; ode();
      for ( i=imin; i<imax; i++ ) {
         _kk[i] = _dt * _dx[i];
         _x[i]  += _kk[i]/6.0 - _qq[i]/3.0;
      }
   }

  public:
   Rkg4( long dimen ) {
      _dim  = dimen;
      _t0   = 0.0;
      _dt   = 0.01;
      _t    = _t0;
      _x    = new double[_dim];
      _dx   = new double[_dim];
      _kk   = new double[_dim];
      _qq   = new double[_dim];

      _inc        = 0;
      _step       = 1;
      _freq       = 0.0;
      _isperiodic = 0;

   }
   virtual ~Rkg4() { 
      delete _x;
      delete _dx;
      delete _kk;
      delete _qq;
   }

   signed long indx( signed long i ) {
#ifdef DEBUG
      if ( i < 1 || _n < i ) {
         cerr << "***Rkg4: index is out of range" << endl;
         exit( -1 );
      }
#endif
      return ( i-1 );
   }

   double dim( void ) {
      return _dim;
   }
   double t( void ) {
      return _t;
   }
   void add_to_t( double delta_t ) {
      _t += delta_t;
   }
   void scale_t( double delta_t ) {
      _t *= delta_t;
   }
   double t0( void ) {
      return _t0;
   }
   Rkg4& t0( double T0 ) {
      _t = _t0 = T0;
      return *this;
   }

   double dt( void ) {
      return _dt;
   }
   Rkg4& dt( double Dt ) {
      _dt = Dt;
      return *this;
   }

   double &x( long i ) {
      return _x[indx(i)];
   }
   double x2pi( long i ) {
      double pi2 = 2.0*M_PI;
      double xx = fmod( _x[indx(i)], pi2 );
      if ( xx > M_PI ) xx -= pi2;
      else if ( xx < -M_PI ) xx += pi2;
      return xx;
   }
#define x_mod_2pi x2pi
   double &dx( long i ) {
      return _dx[indx(i)];
   }

   double period( ) {
      return 2.0*M_PI/_freq;
   }
   unsigned long step( void ) {
      return _step;
   }
   Rkg4& step( unsigned long Step ) {
      _step = Step;
      return *this;
   }
   double &freq( void ) {
      return _freq;
   }
   Rkg4& freq( double Freq ) {
      if ( _step <= 0 ) {
         cerr << "***Rkg4: invalid order of function call." << endl;
         cerr << "         call step(?), then call freq(?)" << endl;
         exit(-1);
      }
      _freq = Freq;
      _dt = 2.0*M_PI/_freq/(double)_step;
      return *this;
   }

   Rkg4& periodic( double Freq, unsigned long Step=128 ) {
      _isperiodic = 1;
      step(Step); freq(Freq);
      return *this;
   }

   Rkg4& noperiodic( double Dt=0.01 ) {
      _isperiodic = 0;
      dt(Dt);
      return *this;
   }

   void solve( int rept=1 ) {
      for ( int i=0; i<rept; i++ ) {
         rkg4();

         _inc = (++_inc)%_step;
         if ( _inc == 0 && _isperiodic ) {
            _t = _t0;
         }
      }
   }

// katu
   void solve_without_update_time( ) {
      rkg4();
      _t -= _dt;
   }
   void update_time( ) {
      _inc = (++_inc)%_step;
      _t += _dt;
      if ( _inc == 0 && _isperiodic ) {
         _t = _t0;
      }
   }

   void poincare( void ) {
      if ( _step <= 0 ) {
         cerr << "***Rkg4: step == 0 for poincare" << endl;
         cerr << "         call step(nonzero) before" << endl;
         exit(-1);
      }
      solve(_step);
   }

};

#endif /* __RKG4_H_ */
