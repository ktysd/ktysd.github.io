global K L;
function y = G(s) # 伝達関数
  global K L;
  g = 9.8;
  y = 1 ./ (s.**2 .+ (L).*s .+ (-g+K));
endfunction
Om=logspace(log10(0.4),1,100);  #周波数(の数列)
logOm=log10(Om);
### over damp ###
K=15; L=3;
GiOm=G(i*Om); # 周波数伝達関数(の数列)
K1=abs(GiOm);  # 振幅比(の数列)
P1=arg(GiOm);  # 位相差(の数列)
### under damp ###
K=15; L=0.5;
GiOm=G(i*Om); # 周波数伝達関数(の数列)
K2=abs(GiOm);  # 振幅比(の数列)
P2=arg(GiOm);  # 位相差(の数列)
subplot(2,1,1); 
plot( logOm, 20*log10(K1), ";over;", logOm, 20*log10(K2), ";under;" ); grid on;
title("Bode Diagram (Gain)");
xlabel("Frequency Om"); 
ylabel("Gain 20*log10(K)");
subplot(2,1,2);
plot( logOm, P1, ";over;", logOm, P2, ";under;" ); grid on;
title("Bode Diagram (Phase)");
xlabel("Frequency log10(Om)"); 
ylabel("Phase P");
pause;
