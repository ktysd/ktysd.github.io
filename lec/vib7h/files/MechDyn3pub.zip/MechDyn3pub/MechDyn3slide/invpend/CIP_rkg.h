#include "Rkg++.h"
#define POW2(a) ((a)*(a))

struct _sysp {
   double m, r, l, g;
   double rod_k, rod_c, th_c, x_c;
   double pd_K, pd_L;
   double mom1, mom2; //impulse strength (momentam)
   double t1, t2;     //suspension time interval
} sysp; /* system parameters */

struct _sysv {
   double f1, f2;     //feedback force variable
   double imp1, imp2; //impulse force variable
} sysv; /* system variables */

class Model: public Rkg4 {
   int irep;
   double d_time;
 public:
   int is_converged, equil[2];
   Model(double time_step = 0.002): Rkg4(8) {

      /*
       * Default parameter values
       */
      sysp.m = 1.0;    // ���1//���_1//���2//���_2�̎���
      sysp.r = 0.3;    // �U�q�_�̒���
      sysp.l = 1.0;    // �����N�_�̒���(�o�l�͎��R��)
      sysp.g = 9.8;    // �d�͉����x
      sysp.rod_k = 5e4;
      sysp.rod_c = 3.0;
      sysp.pd_K  = 50.0;
      sysp.pd_L  = 5.0;
      sysp.th_c  = 0.1;
      sysp.x_c   = 0.1;
      sysp.mom1 = sysp.mom2 = 1.0;

      sysv.imp1 = sysv.imp2 = 0.0;
      d_time = time_step;
      noperiodic(d_time);

      /*
       * Initial conditions
       */
      init_th( 0.0, 0.0 );
      init_dx( 0.0, 0.0 );
      init_dth( 0.0, 0.0 );

      equil[0] = equil[1] = -1;
      is_converged = 0;
      irep = 0;
  }

#define MOD2PI(a) (\
   fabs(fmod(fmod((a)+0.5*M_PI, 2.0*M_PI)-0.5*M_PI,2.0*M_PI)) )
#define MAX(a,b) ( ((a)>(b))? a: b )

  void solve( int n=1 ) {
     if ( irep == 0 ) {
        sysv.imp1 = sysp.mom1 / d_time / (double)n;
        sysv.imp2 = sysp.mom2 / d_time / (double)n;
        irep ++;
     } else {
        sysv.imp1 = sysv.imp2 = 0.0;
     }
     Rkg4::solve(n);
  }
  void solve_with_check( int n=1 ) {
     double eps = 1.0e-3;
     double err_up, err_dn;
     solve(n);
     double th[2] = {MOD2PI(x(3)), MOD2PI(x(7))};
     double dth[2] = {x(4), x(8)};
     for ( int i=0; i<2; i++ ) {
        err_up = MAX(fabs(th[i]),fabs(dth[i]));
        err_dn = MAX(fabs(th[i]-M_PI),fabs(dth[i]));
//        printf( "(%e, %e)\n", err_up, err_dn );
//        printf( "(%e, %e)\n", th[0], th[1] );
        if ( err_up < eps )
           equil[i] = 1; /* up */
        else if ( err_dn < eps )
           equil[i] = 0; /* down */
     }
     if ( equil[0] >= 0 && equil[1] >= 0 ) {
        is_converged = 1;
     }
  }

  void init_th( double th1, double th2 ) {
    x(1) = 0.0;    // ���1�̈ʒu
    x(3) = th1;    // ���_1�̊p�x
    x(5) = x(1) + sysp.r*( sin(th1) - sin(th2) )
      + sqrt(-POW2(sysp.r*cos(th1)-sysp.r*cos(th2))+POW2(sysp.l)); // ���2�̈ʒu
    x(7) = th2;    // ���_2�̊p�x
  }

  void init_dx( double dx1, double dx2 ) {
    x(2) = dx1;    // ���1�̑��x
    x(6) = dx2;    // ���2�̑��x
  }

  void init_dth( double dth1, double dth2 ) {
    x(4) = dth1;    // ���_1�̊p���x
    x(8) = dth2;    // ���_2�̊p���x
  }

  void ode() {

    double x1, x2, dx1, dx2, th1, th2, dth1, dth2;
    x1 = x(1); dx1 = x(2); th1 = x(3); dth1 = x(4);
    x2 = x(5); dx2 = x(6); th2 = x(7); dth2 = x(8);

    /*
     * Default feedback
     */
    sysv.f1 = sysp.pd_K*sysp.r*sin(th1) + sysp.pd_L*sysp.r*dth1*cos(th1);
    sysv.f2 = sysp.pd_K*sysp.r*sin(th2) + sysp.pd_L*sysp.r*dth2*cos(th2);

    /* Sacrifice strategy */
    sysv.f1 += sysv.imp1;
    sysv.f2 += sysv.imp2;

    /* Suspension strategy */
    if ( sysp.t1 <= t() && t() < sysp.t2 ) {
       sysv.f2 = 0.0;
    }

    double DX, DY, Dl2, Dl, dDX, dDY, dDl;
    DX = x2 - x1 + sysp.r*( sin(th2) - sin(th1) );
    DY = sysp.r*( cos(th2) - cos(th1) );
    Dl2 = DX*DX + DY*DY;
    Dl = sqrt(Dl2);
    dDX = dx2 - dx1 + sysp.r*( dth2*cos(th2) - dth1*cos(th1) );
    dDY = sysp.r*( dth1*sin(th1) - dth2*sin(th2) );
    dDl = 2.0*(dDX*DX + dDY*DY);
#define QQ(th) (cos(2.0*th)-3.0)
#define G1(th,dth) ( 2.0*sin(th) * (sysp.g*cos(th) - sysp.r*dth*dth) /QQ(th) )
#define G2(th,dth) ( 2.0*sin(th) * (-2.0*sysp.g + sysp.r*cos(th)*dth*dth) /sysp.r/QQ(th) )
#define H1(th) ( sin(th) * ( DY*cos(th) + DX*sin(th) ) /sysp.m/QQ(th) )
#define H2(th) ( ( DX*cos(th) - 2.0*DY*sin(th) ) /sysp.m/sysp.r/QQ(th) )
    dx(1) = x(2);
    dx(2) = - sysp.x_c*dx1 - 2.0/(sysp.m*QQ(th1))  * sysv.f1
            - dDl*H1(th1)/Dl2       * sysp.rod_c 
            - 2.0*(Dl-sysp.l)*H1(th1)/Dl * sysp.rod_k
            + G1(th1,dth1);
    dx(3) = x(4);
    dx(4) = - sysp.th_c*dth1 + 2.0*cos(th1)/(sysp.m*sysp.r*QQ(th1))  * sysv.f1
            - dDl*H2(th1)/Dl2       * sysp.rod_c 
            - 2.0*(Dl-sysp.l)*H2(th1)/Dl * sysp.rod_k
            + G2(th1,dth1);
    dx(5) = x(6);
    dx(6) = - sysp.x_c*dx2 - 2.0/(sysp.m*QQ(th2))  * sysv.f2
            + dDl*H1(th2)/Dl2       * sysp.rod_c 
            + 2.0*(Dl-sysp.l)*H1(th2)/Dl * sysp.rod_k
            + G1(th2,dth2);
    dx(7) = x(8);
    dx(8) = - sysp.th_c*dth2 + 2.0*cos(th2)/(sysp.m*sysp.r*QQ(th2))  * sysv.f2
            + dDl*H2(th2)/Dl2       * sysp.rod_c 
            + 2.0*(Dl-sysp.l)*H2(th2)/Dl * sysp.rod_k
            + G2(th2,dth2);
   }   
};
