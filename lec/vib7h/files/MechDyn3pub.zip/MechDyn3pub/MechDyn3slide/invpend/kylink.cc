/* 2007-11-21 yoshidak */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "CIP_rkg.h"
Model *model;

#ifdef ANIM
#include "local_gl.h"
#endif

int main(int argc, char *argv[]) {
   double t1, t2, th1, th2, mom1, mom2;

   model = new Model;
//   model->rod_k = 5e4;
//   model->rod_c = 3.0;
//   model->pd_K  = 50.0;
//   model->pd_L  = 5.0;
//   model->th_c  = 0.1;
//   model->x_c   = 0.1;
//   model->pd_F  = 0.0;
   if ( argc == 8 +1) {
      sysp.pd_K = atof( argv[1] );//180*M_PI;
      sysp.pd_L = atof( argv[2] );//180*M_PI;
      th1 = atof( argv[3] );
      th2 = atof( argv[4] );
      mom1 = atof( argv[5] );
      mom2 = atof( argv[6] );
      t1 = atof( argv[7] );
      t2 = atof( argv[8] );
      model->init_th( th1, th2 );
      sysp.mom1 = mom1;     
      sysp.mom2 = mom2;     
      sysp.t1 = t1;     
      sysp.t2 = t2;     
   }
   else {
      fprintf( stderr, "usage: %s K L th1 th2 mom1 mom2 t1 t2\n", argv[0] );
//      fprintf( stderr, "pd_F=0 :The mouse is not used.\n");
      return 0;
   }
   
#ifndef ANIM
#define MAXN 10000
   int i;
   for ( i=0; i<=MAXN; i++ ) {
      model->solve_with_check(5);
      if ( model->is_converged )  break;
   }
   if ( mom1 == 0.0 && mom2 == 0.0 ) {
      printf( "%e %e ", th1, th2 );
   } else {
      printf( "%e %e ", sysp.mom1, sysp.mom2 );
   } 
   printf( "%5d ", i );
   if ( i < MAXN )
      printf( "%d %d\n", model->equil[0], model->equil[1] );
   else
      printf( "nil\n" );
#else
//   glutInitWindowSize(650, 650);
   glutInitWindowSize(700, 350);
   glutInitWindowPosition(100, 0);
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
   glutCreateWindow(argv[0]);
   glutDisplayFunc(gl_display);
   glutKeyboardFunc(gl_keyboard);
   glutMotionFunc(gl_motion);
   glutMouseFunc(gl_mouse);
   glutPassiveMotionFunc(gl_pass_motion);
   glutTimerFunc ( D_TIMER, gl_timer, 0 );
   glClearColor(1.0, 1.0, 1.0, 0.0);
   glutMainLoop();
#endif

   return 0;
}

