#define ANIM 1
#include "kylink.cc"
