damp=0.5; C1=-1.0; C2=0.5; C3=3.0;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-damp*x(2)-C1*x(1) -C2*x(1)*(x(2)^2) -C3*(x(1)^3);
 return dx';
}
{t,z1}=OdeAuto(0.0,20.0, [0,0.01]',eqn);
{t,z2}=OdeAuto(0.0,20.0, [0,-0.01]',eqn);
gplot(t,z1(1,:),{"x1"});
pause;
greplot(t,z2(1,:),{"x1"});
pause;
gplot(z1(1,:),z1(2,:),{"z1"});
pause;
greplot(z2(1,:),z2(2,:),{"z2"});
