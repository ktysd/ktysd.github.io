zeta=0.1; A=1.0;
Real om;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-2.0*zeta*x(2) -x(1) +A*cos(om*t);
 return dx';
}
Func Real Vib(freq)
  Real freq;
{
 Array t,x,f;
 Integer len;
 Real x1max;
 om=freq;
 {t,x}=Ode45Auto(0.0,80.0,[0,0]',eqn);
 len=length(t);
 x1max=max(x(1,len/2:len));
 gplot_reset();
 gplot_title(sprintf("max x1=%f",x1max));
 gplot(t,x(1,:),{"x1"});
 return x1max;
}
Array amp;
Om=[0.2:0.1:1.8];//�e��
gplot_cmd("set yrange[-5:5]");
for(i=1;i<=length(Om);i++){
 amp(i)=Vib(Om(i));
}
gplot_title("");
gplot_xlabel("Frequency om");
gplot_ylabel("Responses");
gplot_cmd("set yrange[0:5]");
gplot(Om,amp,{"max x1(t)"},{"w p"});//with points �̗�
Func Real Kfunc(x)
  Real x;
{
 return A/sqrt((1-x^2)^2 +(2*zeta*x)^2);
}
Array K;
Om=[0.2:0.01:1.8];//�ׂ���
for(i=1;i<=length(Om);i++){
  K(i) = Kfunc(Om(i));
}
pause;
greplot(Om,K,{"K(Om)"});
