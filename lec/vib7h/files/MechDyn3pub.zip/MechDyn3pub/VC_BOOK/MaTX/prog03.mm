Real Om;
zeta=0.1; omn=1.0; Om=0.0;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-2.0*zeta*omn*x(2) -omn^2*x(1) +cos(Om*t);
 return dx';
}
Func Real Vib(freq)
  Real freq;
{
 Array t,x,f;
 Integer len;
 Om=freq;
 {t,x}=Ode45Auto(0.0,80.0,[0,0]',eqn);
 f = cos(Om*t);
 gplot_reset();
 gplot_xlabel("Time t");
 gplot_ylabel("Amplitude y");
 gplot_cmd("set yrange[-5:5]");
 gplot_title(sprintf("Om=%f",freq));
 printf("Om=%f",freq);
 gplot(t,[[f][x(1,:)]],{"f(t)","x1","aaa"});
 gplot_cmd("set title");
 len=length(t);
 return max(x(1,len/2:len));
}
om=[0.2:0.05:1.8];
n=length(om);
Array amp;
for (i=1; i<=n; i++) {
 amp(i)=Vib(om(i));
}
gplot_xlabel("Frequency om");
gplot_ylabel("Max x1");
gplot_cmd("set yrange[0:5]");
gplot(om,amp,{"K(Om)"});
