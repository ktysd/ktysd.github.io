for i in prog??.mm; do
echo "----------------------------------------"
echo "matx $i -e pause"
matx $i -e pause
done
