m = 1.0; c = 0.5; k = 1.0;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-(c/m)*x(2)-(k/m)*x(1);
 return dx';
}
z0=[1,0]';
{t,z}=OdeAuto(0.0,25.0,z0,eqn);
gplot(t,z(1,:),{"x1"});
