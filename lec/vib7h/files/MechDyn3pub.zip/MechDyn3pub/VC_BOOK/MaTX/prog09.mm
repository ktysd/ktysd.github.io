kapa=0.1; c1=0.1; k1=1.0; c2=0.1; k2=1.0;
Func Matrix eqn(t,x,u)
   Real t; Matrix x, u;
{
 Matrix dx;
 dx(1)=x(2);
 dx(2)=-2.0*c1*k1*x(2) -kapa*2.0*c2*k2*(x(2)-x(4))
       -k1^2*x(1) -kapa*k2^2*(x(1)-x(3))+cos(t);
 dx(3)=x(4);
 dx(4)=-2.0*c2*k2*(x(4)-x(2)) -k2^2*(x(3)-x(1));
 return dx';
}
Func void Vib(k)
  Real k;
{
 Array t,x,f;
 Integer len;
 k2=k;
 {t,x}=Ode45Auto(0.0,80.0,[0,0,0,0]',eqn);
 gplot_reset(); gplot_cmd("set yrange[-8:8]");
 gplot_title(sprintf("k2=%f",k2));
 gplot(t,[[x(1,:)][x(3,:)]], {"x1","x3"});
}
k=[0.1:0.1:2];
for ( i=1; i<=length(k); i++) {
  Vib(k(i));
  pause 0.5;
}
