zeta=0.1;
A=1.0;
j=(0,1);//�����

Func void bode( zeta )
Real zeta
{
  Polynomial s;
  Rational G;
  Array Om, Gjw, K, p;
  s=Polynomial("s");//¿�༰�ѿ�
  G=(s+1)/(s^2+2*zeta*s+1);
  Om=logspace(-2.0,2.0,100);
  Gjw=eval(G,j*Om);//����
  K=20*log10(abs(Gjw));//������
  p=arg(Gjw);//���꺹
  gplot_title("Gain (Bode)");
  gplot_xlabel("Frequency Om");
  gplot_ylabel("Amplitude K");
  gplot_semilogx(Om,K,{"K(Om)"});
  pause;
  gplot_title("Phase (Bode)");
  gplot_ylabel("Phase p");
  gplot_semilogx(Om,p,{"p(Om)"});
  pause;
}
