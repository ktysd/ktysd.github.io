platex book
platex book
mendex book
platex book
dvipdfmx -p 182mm,257mm book.dvi
cp book.pdf `date +vcbook%y%m%d.pdf`

