#/usr/bin/perl

$proc_type=$ARGV[0];
$target_base=$ARGV[1];
$real_size=$target_base;
#$real_size=~s|.*-([ab][45])$|$1|gex;
$real_size="a5";
printf("%s,%s,%s\n", $proc_type,$target_base,$real_size);

if ( $proc_type =~ m/dvi/ ) {
  die "$0: $target_base.tex: No such file" if ( -e $target_base.tex );
  latex($target_base);
}
elsif ( $proc_type =~ m/ps/ ) {
  die "$0: $target_base.dvi: No such file" if ( -e $target_base.dvi );
  dvips($target_base,$real_size);
}
else {
  print "usage: $0 {dvi,ps} base_name\n";
  exit;
}



sub latex {
  local($bname)=@_;
  local $warning=0;
  local $cnt=0;
  do {
    $warning=0;$cnt++; 
    open(LATEX,"platex $bname.tex|");
    while(<LATEX>){
      $warning = 1 if( $_ =~ m/may have changed/ );
      print "try" . $cnt . ": " . $_;
    }
    close(LATEX);
  } while($warning);
}

sub dvips {
  local($bname,$rsize)=@_;
  open(DVIPS,"dvipsk -Ppdf -f -t $rsize<$bname.dvi|psresize -P$rsize -pa4|");
#  open(PS2UP,"|/home/yoshidak/bin/ps2up-lmargin>$bname.ps");
  open(PS2UP,">$bname.ps");
  while (<DVIPS>){
    s/DocumentPaperSizes:\s$rsize/"DocumentPaperSizes: a4"/e;
    print PS2UP;
    print PS2UP '%%Orientation: Landscape'."\n" if (/^%%Pages:/);
  }
  close(DVIPS);
  close(PS2UP);
}

#dvips -f -t $real_size < $target_base.dvi \
#| \
#| sed "s/DocumentPaperSizes: b5/DocumentPaperSizes: $real_size/" \
#| 
#
