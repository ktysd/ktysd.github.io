#!/bin/bash
xdvi -geometry 930x690+0+0 -paper b5 -s 5 book.dvi &
#xdvi -geometry 930x690+0+0 -paper a5 -s 4 book.dvi &
#sleep 1
#emacs -g 68x42-0+0 basis.tex&

