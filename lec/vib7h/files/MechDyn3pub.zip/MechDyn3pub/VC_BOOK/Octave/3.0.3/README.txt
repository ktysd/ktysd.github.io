> octave
GNU Octave, version 3.0.1
 :
 :
octave:1> source "prog01.m"
octave:2> exit
> 

