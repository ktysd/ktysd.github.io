global kapa c1 k1 c2 k2;
kapa=0.1; c1=0.1; k1=1.0; c2=0.1; k2=1.0;
function dx = eqn(x, t)
 global kapa c1 k1 c2 k2;
 dx(1)=x(2);
 dx(2)=-2.0*c1*k1*x(2) -kapa*2.0*c2*k2*(x(2)-x(4)) \ #�Ԥ�³�����
       -k1**2*x(1) -kapa*k2**2*(x(1)-x(3))+cos(t);
 dx(3)=x(4);
 dx(4)=-2.0*c2*k2*(x(4)-x(2)) -k2**2*(x(3)-x(1));
endfunction
t = linspace(0,80,200);
k = linspace(0.1,2,20);
x0=[0;0;0;0];
for j = 1:20;
  k2 = k(j);
  x = lsode("eqn", x0, t);
  plot(t, x(:,1), ";x1;", t, x(:,3), ";x3;"); grid on;
  title(sprintf("k2=%f",k2));
  drawnow();
endfor
