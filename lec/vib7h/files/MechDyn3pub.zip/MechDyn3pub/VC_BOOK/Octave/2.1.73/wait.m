function wait()
printf("Please hit any key to continue !!\n");
pause
endfunction
