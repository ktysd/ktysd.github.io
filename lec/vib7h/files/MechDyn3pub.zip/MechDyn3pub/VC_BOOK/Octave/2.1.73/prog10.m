global damp C1 C2 C3;
damp=0.5; C1=-1.0; C2=0.5; C3=3.0;
function dx = eqn(x, t)
 global damp C1 C2 C3;
 dx(1)=x(2);
 dx(2)=-damp*x(2)-C1*x(1) -C2*x(1)*(x(2)^2) -C3*(x(1)^3);
endfunction
x01=[0;0.01];
x02=[0;-0.01];
t = linspace(0,20,100);
z1 = lsode("eqn", x01, t );
z2 = lsode("eqn", x02, t );
plot(t,z1(:,1),";z1;"); wait;
plot(t,z1(:,1),";z1;",t,z2(:,1),";z2;"); wait;
plot(z1(:,1),z1(:,2),";z1;"); wait;
plot(z1(:,1),z1(:,2),";z1;",z2(:,1),z2(:,2),";z2;"); wait;
