global om;
function dx = model(x, t)
  global om;
  m=1.0; c=0.2; k=1.0;
  dx(1) = x(2);
  dx(2) = -(c/m)*x(2) - (k/m)*x(1) + cos(om*t);
endfunction
freq = linspace(0.2,1.6,29);
gset yrange[-5:5];
gset xlabel "Time t"; gset ylabel "Amplitude y"
x0 = [0; 0.1]; t = linspace(0, 100, 300);
for i = 1:29
   om = freq(i);
   f = cos(om*t);
   x = lsode("model", x0, t);
   title(sprintf("Wave form (om = %.3f)",om));
   plot(t,f,";Input;",t,x(:,1),";Response;")
   sleep(1);
   xmax(i) = max(x(250:300, 1));
endfor
wait;
gset yrange[0:5]; gset xlabel "Frequency om"
title("Response Curve");
plot(freq, xmax); wait;
