global zeta om_n;
zeta=0.2; om_n=1;
function dx = eqn(x, t)
  global zeta om_n;
  dx(1)=x(2);
  dx(2)=-2*zeta*om_n*x(2)-(om_n**2)*x(1)+Force(t);
endfunction
function y = Force(t)
  if ( t >= 0 ) y=1;
  else y=0;
  endif
endfunction
x0 = [0; 0];
t = linspace(0, 25, 200);
x = lsode("eqn", x0, t);
plot(t, x(:, 1)); grid on;
title("Step response")  # ���ƥå״ؿ�
printf("Hit any key!\n"); pause;
function y = Force(t)   # �����˱��Υ���ѥ륹�ؿ�
  if ( t == 0 ) # ���ָ��� 
#    y=100000000000000000000000.0;
    y=10000000000.0;
  else          # ����ʳ�
    y=0;
  endif
endfunction
x1 = lsode("eqn", x0, t);
plot(t, x1(:, 1)); grid on;
title("Impulse response (false)");
printf("Hit any key!\n"); pause;
function y = Force(t)   # ���Ū�ʥ���ѥ륹�ؿ�
  delta_t =25/200;
  if ( 0 <= t && t <= delta_t ) # Ŭ���ʾ����
    y=1/delta_t;  # ����1
  else                          # ����ʳ�
    y=0;
  endif
endfunction
x2 = lsode("eqn", x0, t);
plot(t, x2(:, 1)); grid on;
title("Impulse response (true)");
printf("Hit any key!\n"); pause;
plot(t, x1(:, 1), ";false;", t, x2(:, 1), ";true;"); grid on;
title("Impulse response (false/true)");
printf("Hit any key!\n"); pause;
