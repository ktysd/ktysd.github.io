global om;
function dx = model(x, t)
  global om;
  m=1.0; c=0.2; k=1.0;
  dx(1) = x(2);
  dx(2) = -(c/m)*x(2) - (k/m)*x(1) + cos(om*t);
endfunction
freq = linspace(0.2,1.6,29);
x0 = [0; 0.1]; t = linspace(0, 100, 300);
grid on; axis([0,100,-6,6]);
for i = 1:29
   om = freq(i);
   f = cos(om*t);
   x = lsode("model", x0, t);
   plot(t,f,";Input;",t,x(:,1),";Response;");
   title(sprintf("Wave form (om = %.3f)",om));
   xmax(i) = max(x(250:300, 1));
endfor
pause(1); axis([0.2,1.6,0,6]);
plot(freq, xmax, ";Response Curve;");
xlabel("Frequency om"); ylabel("Amplitude");
