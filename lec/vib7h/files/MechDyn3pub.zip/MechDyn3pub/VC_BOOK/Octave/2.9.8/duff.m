function dx = eqn(x, t)
 dx(1)=x(2);
 dx(2)=-x(2) +x(1) -(x(1)^3);
endfunction
x01=[0;0.01];
x02=[0;-0.01];
t = linspace(0,20,100);
z1 = lsode("eqn", x01, t );
z2 = lsode("eqn", x02, t );
plot(t,z1(:,1),";z1;"); grid on;
printf( "Hit any key!\n"); pause;
plot(t,z1(:,1),";z1;",t,z2(:,1),";z2;"); grid on;
printf( "Hit any key!\n"); pause;
plot(z1(:,1),z1(:,2),";z1;"); grid on;
printf( "Hit any key!\n"); pause;
plot(z1(:,1),z1(:,2),";z1;",z2(:,1),z2(:,2),";z2;"); grid on;
