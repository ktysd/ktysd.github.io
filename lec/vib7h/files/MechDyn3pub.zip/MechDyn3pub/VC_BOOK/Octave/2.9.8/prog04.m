global zeta A om;
zeta=0.1; A=1.0;
function dx = model(x, t)
  global zeta A om;
  dx(1) = x(2);
  dx(2) = -2*zeta*x(2) - x(1) + A*cos(om*t);
endfunction
om1 = linspace(0.2,1.6,15);
x0 = [0; 0.1]; t = linspace(0, 100, 300);
grid on; axis([0,100,-6,6]);
for i = 1:15
   om = om1(i);
   f = cos(om*t);
   x = lsode("model", x0, t);
   plot(t,f,";Input;",t,x(:,1),";Response;");
   title(sprintf("Wave form (om = %.3f)",om));
   amp1(i) = max(x(250:300, 1));
endfor
axis([0.2,1.6,0,6]);
plot(om1, amp1, "o;Numerical;");
title("Response Curve");
printf("Hit any key!\n"); pause;
function y = K(omega)
  global zeta A;
  y=A./sqrt((1.-omega.**2).**2 .+(2.*zeta.*omega).**2);
endfunction
om2 = linspace(0.2,1.6,100);
amp2 = A*K(om2);
plot(om1, amp1,"o;Numerical;", om2, amp2,";Analytical;" );
