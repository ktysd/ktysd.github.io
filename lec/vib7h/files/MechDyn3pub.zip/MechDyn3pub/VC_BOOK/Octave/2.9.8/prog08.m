global zeta omn;
zeta=0.1; omn=1.0;
function dx = eqn(x, t)
  global zeta omn;
  dx(1) = x(2);
  dx(2) = -2*zeta*omn*x(2)-(omn**2)*x(1)+F(t);
endfunction
function y = F(t) # ��ͳ��ư
 y=0.0;  # ��˳��ϡᣰ
endfunction
x0 = [0; 1];      # ����ͤ��ѹ�
t = linspace(0, 25, 100);
x = lsode("eqn", x0, t);
plot(t, x(:, 1)); grid on;
