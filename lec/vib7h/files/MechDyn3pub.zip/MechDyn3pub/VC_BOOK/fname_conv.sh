mv chap00uu.tex preface.tex
mv chap01.tex chap00.tex
mv chap02.tex chap01.tex
mv chap03.tex chap02.tex
mv chap04.tex chap03.tex
mv chap10uu.tex chap04.tex
#chap05
#chap06
#chap07
mv chap08uu.tex chap08.tex
mv chap09uu.tex chap09.tex
mv chap11uu.tex chap10.tex
mv chap12.tex chap11.tex
mv chap13.tex chap12.tex
mv chap14uu.tex chap13.tex
mv chap15uu.tex chap14.tex
#chapA1uu
#chapA2
#chapA3
#chap99
