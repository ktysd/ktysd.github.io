files="chap00uu \
chap01 \
chap02 \
chap03 \
chap04 \
chap10uu \
chap05 \
chap06 \
chap07 \
chap08 \
chap09 \
chap11 \
chap12 \
chap13 \
chap14uu \
chap15 \
chapA1uu \
chapA2 \
chapA3"

#for i in $files; do \
#echo $i;\
#nkf -w $i.tex\
#| sed -e 's/\({\\bf [^}]*$\)/\
#\1\
#/g'\
#| sed -n -e '/{\\bf [^}]*$/p' \
#done

(for i in $files; do \
nkf -w $i.tex\
| sed -e 's/\({\\bf [^}]*}\)/\
\1\
/g'\
| sed -n -e '/{\\bf [^}]*}/p'\
| sed -e 's/{\\bf \([^}]*\)}/\1/g'\
| sort | uniq ; \
done) > conv.tmp

words=`cat conv.tmp`

(for i in $words; do
  kana=`echo $i| nkf -e | kakasi -KH -JH | nkf -w`
  echo "$kana\t$i"
done) | sort

#
