for i in *.???; do
  nkf -e $i \
| sed -e 's/includeprg/includeprgO/g' \
| sed -e 's/{kadai}/{exercise}/g' \
| sed -e 's/{remark}/{theorem}/g' \
| sed -e 's/\\rpagetab/prtab/g' \
| sed -e 's/\\rchap{/\\prchap{/g' \
| sed -e 's/\\rchaponly{/\\rchap{/g' \
| sed -e 's/\\lkad/\\label/g' \
| sed -e 's/\\rkad/\\thref/g' \
| sed -e 's/\\lrem/\\label/g' \
| sed -e 's/\\rrem/\\thref/g' \
| sed -e 's/\\rtheo/\\thref/g' \
| sed -e 's/\\prtheo/\\pthref/g' \
| sed -e 's/\\prform/\\pthref/g' \
| sed -e 's/\\prrem/\\pthref/g' \
| sed -e 's/\\rprog/\\prprog/g' \
| sed -e 's/��/��/g' \
> ../$i
done
