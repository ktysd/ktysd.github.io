global m1 m2 r;
m2=1/3; m1=1-m2; r=1;
function dy = eqn(y, t)
 global m2 m1 r;
 ut = 0.7*y(1) + 1.3*y(2) + 20*y(3) + 4*y(4); # ← (1)ここに制御力！
 A = [m1+m2, m2*r*cos(y(3)); cos(y(3)),r];
 b = [m2*r*(y(4)**2)*sin(y(3))+ut; 9.8*sin(y(3))];
 h = A\b;  #(Aの逆行列)*bと同じ．inv(A)*bと書くより速い
 dy(1) = y(2);
 dy(2) = h(1);
 dy(3) = y(4);
 dy(4) = h(2);
endfunction
n = 500;
x0 = [0; 0; 0.5; 0]; # ← (2)ここに初期値！
t = linspace(0, 0.02*n, n);
x = lsode("eqn", x0, t);
grid on;
for i=1:n
 title(sprintf("x=%f, angle=%f",x(i,1),x(i,3)));
 x1x = x(i,1); x1y = 0;                          #台車の座標
 x2x = x1x + r*sin(x(i,3)); x2y = r*cos(x(i,3)); #振り子の座標
 plot([x1x,x2x],[x1y,x2y]);                      #棒の描画
 axis([-5.5, 5.5, -5.5, 5.5],"square");
 if ( i==1 ) pause(2);
 else pause(0.002); #この行の数値を大きくすると遅くなる
 endif
endfor
