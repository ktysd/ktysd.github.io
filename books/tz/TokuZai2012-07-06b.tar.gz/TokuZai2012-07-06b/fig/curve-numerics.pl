#!/usr/bin/perl

@data=();
while(<>) {
  chop;
  split;
  @data = (@data, [@_]);
}

$datan=@data;
for($i=1; $i<@data-1; $i++) {

  $a[0] = -($data[$i][0]-$data[$i-1][0])/($data[$i][1]-$data[$i-1][1]);
  $a[1] = -($data[$i+1][0]-$data[$i][0])/($data[$i+1][1]-$data[$i][1]);

  $x[0] = ($data[$i][0]+$data[$i-1][0])/2;
  $y[0] = ($data[$i][1]+$data[$i-1][1])/2;

  $x[1] = ($data[$i+1][0]+$data[$i][0])/2;
  $y[1] = ($data[$i+1][1]+$data[$i][1])/2;

  $b[0] = -$a[0]*$x[0]+$y[0];
  $b[1] = -$a[1]*$x[1]+$y[1];

  $X = -($b[0]-$b[1])/($a[0]-$a[1]);
  $Y = ($a[0]*$b[1]-$a[1]*$b[0])/($a[0]-$a[1]);
  $X0 = $data[$i][0];
  $Y0 = $data[$i][1];
  $R = sqrt( ($X-$X0)*($X-$X0) + ($Y-$Y0)*($Y-$Y0) );

  $s[0] = ($X-$X0)/$R;
  $s[1] = ($Y-$Y0)/$R;
  $r = 0.3/$R;

  printf( "%e %e\n", $X0, $Y0 );
  printf( "%e %e\n\n", $X0 + $r*$s[0], $Y0 + $r*$s[1] );
}

