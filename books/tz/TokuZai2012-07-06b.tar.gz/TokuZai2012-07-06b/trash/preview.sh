xdvi -paper a5 -expert main.dvi&
