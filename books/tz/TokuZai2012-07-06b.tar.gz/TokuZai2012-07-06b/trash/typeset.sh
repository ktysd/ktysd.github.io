#!/bin/bash
dvipsk -f -t a5 < main.dvi | psresize -Pa5 -pa4 | ps2up-lmargin > main.ps
#gv main.ps2up
