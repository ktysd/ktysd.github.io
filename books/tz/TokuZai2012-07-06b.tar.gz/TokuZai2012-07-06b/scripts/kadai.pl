#!/usr/bin/perl

open(MAIN,"<main.tex");
open(KADAI,">kadai.tex");
system("cp main.aux kadai.aux");
@chaplist=();
$\="\n";
while(<MAIN>) {
  chop;
  $line=$_;
  if ( $line =~ s/^ *\\input{([0-9a-zA-Z.]+)}/$1/ ) {
     @chaplist=(@chaplist, $line.".tex");
  }
}
print KADAI <<EOF1;
\\documentclass[a4j]{jreport}
\\usepackage{graphicx}
\\usepackage{eclbkbox}
\\usepackage{ascmac}
\\usepackage{ptexmath}
\\usepackage[exercise]{kythm}
\\usepackage{main}
\\usepackage{refs}
\\usepackage{eqnarray2}

\\def\\danraku/{\\relax}
\\newtheorem{kadai}{����}
\\newtheorem{renshu}{����}

\\include{DATE}
\\def\\simprefix/{\$\\clubsuit\$}
\\pagestyle{headings}
\\MaTX

\\begin{document}
\\twocolumn
EOF1

foreach(@chaplist) {
  $file=$_;
  print KADAI "\\subsection*{$file}";
  open(FILE,"<$file");
  $kadai=0;
  while(<FILE>) {
    chop;
    $line=$_;
    $line=~ s/\\kadlabel{[^}]*}//;
    if ( $line =~ m/^ *\\begin{kadai}.*/ ) {
       $kadai=1;
    }
    if ( $kadai ) {
       print KADAI $line;
    }
    if ( $line =~ m/^ *\\end{kadai}.*/ ) {
       $kadai=0;
    }
  }
}
close(MAIN);

print KADAI <<EOF2;
\\end{document}
EOF2
close(KADAI);
system("platex kadai");

